package com.travel.itinerary.travelItinerary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelItineraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelItineraryApplication.class, args);
	}

}
