package com.travel.itinerary.travelItinerary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelItineraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
