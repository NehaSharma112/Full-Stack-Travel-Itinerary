package com.travel.itinerary.travelItinerary.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelItineraryBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelItineraryBackendApplication.class, args);
	}

}
