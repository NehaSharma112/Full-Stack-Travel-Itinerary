package com.travel.itinerary.travelItinerary.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelItineraryBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
